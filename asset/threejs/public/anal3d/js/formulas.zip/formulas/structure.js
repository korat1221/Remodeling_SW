
// 입력 : color
// 출력 : 실수
formula.push("구조체 흡수율", (o) => {
    let wall_pf = {
        "흰색": 0.3,
        "밝음": 0.4,
        "보통": 0.6,
        "어두움": 0.8,
        "검은색": 0.9
    }; // 해당 내용은 Data Sheet (A1:C6) 확인

    return wall_pf[o.color];
});

// 입력 : type (법규 | 계산), kind (외벽 | 지붕 | 바닥 | 문 | 창호), boundary (직접외기 | 간접외기), region, yyyymm, law(법규제목), ext_int_R(ISO 6946 | 건축물에너지절약기준), lambda[], thickness[]
// 출력 : {"u_val":실수, "temp":배열, "R":배열, "R_sum":실수, "thickness_sum" : 실수,"int_R":실수,"ext_R":실수}
formula.push("구조체 열관류율", (o) => {
    var ret = null;

    if (o.type == "법규") {
        executeSQL(null, "SELECT * FROM si_passive_db WHERE db_name=21 AND col1 = '" + o.law + "' AND col2 = '" + o.yyyymm + "' AND col3 = '" + o.region + "'", function(data){
            if (data.length > 0) {
                let kinds = {"외벽":0,"지붕":1,"바닥":2,"문":3,"창호":4};
                let col = kinds[o.kind] * 2 + (o.boundary == "직접외기" ? 0 : 1) + 4;
    
                ret = {"u_val":data[0]['col' + col]};
            }
        });
    }
    else {
        let data_R = {
            "ISO 6946": {
                "외벽":{
                    "실내": 0.13,
                    "간접외기": 0.13,
                    "직접외기": 0.04,
                    "지면": 0,
                },
                "지붕":{
                    "실내": 0.10,
                    "간접외기": 0.10,
                    "직접외기": 0.04,
                    "지면": 0,
                },
                "바닥":{
                    "실내": 0.17,
                    "간접외기": 0.17,
                    "직접외기": 0.04,
                    "지면": 0,
                }
            },
            "건축물의 에너지절약설계기준": {
                "외벽":{
                    "실내": 0.11,
                    "간접외기": 0.11,
                    "직접외기": 0.043,
                    "지면": 0.11,
                },
                "지붕":{
                    "실내": 0.086,
                    "간접외기": 0.086,
                    "직접외기": 0.043,
                    "지면": 0.086,
                },
                "바닥":{
                    "실내": 0.086,
                    "간접외기": 0.15,
                    "직접외기": 0.043,
                    "지면": 0.15,
                }
            }
        };

        ret = {"u_val":0.0, "temp":[], "R":[], "R_sum":0.0, "thickness_sum" : 0.0,"int_R":data_R[o.ext_int_R][o.kind]["실내"],"ext_R":data_R[o.ext_int_R][o.kind][o.boundary]};

        if (o.thickness) o.thickness.forEach((el, idx) => {
            ret.thickness_sum += el;
            ret.R[idx] = el / 1000 / o.lambda[idx];
            ret.R_sum += ret.R[idx];
        });

        // 계산일 경우 열관류율 계산 (최종)
        ret.R_sum += ret.ext_R + ret.int_R;

        ret.u_val = 1 / (ret.R_sum);

        // 그래프 온도구배 계산 
        var gap = (20 - (-5)) / ret.R_sum ;

        ret.temp.push(20 - gap * ret.int_R);      // 실내 표면

        ret.R.forEach((el) => {
            ret.temp.push(ret.temp[ret.temp.length - 1] - gap * el);  // 위에서 계산된 석고보드 열저항 R[0]
        });
        
        ret.temp.push(ret.temp[ret.temp.length - 1] - gap * ret.ext_R);      // 실내 표면

        // 소수점 넷째자리까지 허용.
        ret.R.forEach((e,i) => {
            ret.R[i] = e.toFixed(4);
        });
        ret.u_val = ret.u_val.toFixed(4);
        ret.R_sum = ret.R_sum.toFixed(4);
        ret.int_R = ret.int_R.toFixed(4);
        ret.ext_R = ret.ext_R.toFixed(4);
    }

    return ret;
});


